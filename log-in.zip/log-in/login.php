<?php

$servername="localhost";
$username="root";
$password="";
$dbname="login";

$connection=mysqli_connect($servername,$username,$password,$dbname);
if($connection)
{
    // echo "Connection Successful";
}else{
    echo "Error!";
}
// if(isset(['email']))
// {
$email=$_POST['email'];
$psd=$_POST['pwd'];

$sql="select * from tbl_reg where email='$email' and password='$psd'";
$result=mysqli_query($connection,$sql);
$row=mysqli_fetch_array($result);
$count=mysqli_num_rows($result);
if($count==1)
{
    header('location: loginsuccessful.php');
}
else
{
    header('location: loginfailed.php');
}
// $row=mysqli_fetch_array($result);
// if($row['email']==$email && $row['password'==$psd])
// {
//     header('location: loginsuccessful.php');
// }
// else
// {
//     header('location: loginfailed.php');
// }
// if(mysqli_num_rows($result)==1)
// {
//     header('location: loginsuccessful.php');
// }
// else
// {
//     header('location: loginfailed.php');
// }
// }
