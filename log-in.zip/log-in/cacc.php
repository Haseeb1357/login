<html>
<head><center>
<font size="30" color="green" family="verdina"><h2><u>User Registration</u></h1></font>
</center></head>
<body bgcolor="yellow">
<form action="accregistration.php" method="POST">
<pre>
				<input type="text" name="name" placeholder="Full Name" size="30">		<input type="text" name="uname" placeholder="User Name" size="30"> <br>
				<input type="email" name="email" placeholder="E-Mail" size="30">		<input type="text" name="phone" placeholder="Phone Number" size="30"> <br>
				<select placeholder="Gender" name="Gender">
				<option> Male </option>
				<option> Female </option>
				</select>					<input type="password" name="pwd" placeholder="Password" size="30"> <br>
				<input type="password" name="pwd" placeholder="Confirm Password" size="30"> <br>
								<input type="submit" name="submit" >
				</pre>
</form>
</body>
</html>