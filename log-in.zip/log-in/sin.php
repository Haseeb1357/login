<html>
<head><center>
<font size="30" color="red" family="arial"><h2><u>User Login</u></h1></font>
</center></head>
<body bgcolor="yellow">
<form action="login.php" method="POST">
<pre>
						<input type="email" name="email" placeholder="E-Mail" size="30"> <br>
						<input type="password" name="pwd" placeholder="Password" size="30"> <br>
								<input type="submit" name="submit" ><br>
						<a href="registration.html"><u>Create Account</u></a>		<a href="forgot.html"><u>Forgot Password?</u></a>
</pre>
</body>
</html>